# 上海大学机电工程与自动化学院本科毕业论文模板

## 模板用法

### 本地

1. 以 **管理员权限** 安装 TexLive
2. 安装 TexStudio（可选）
3. 使用 TexWorks 或 TexStudio 打开 ==projpaper.tex==
4. 在 TexWorks 中，选择 XeLaTeX，点击排版；在 TexStudio 中按 ==F5== 构建运行

### 远程（Overleaf）

1. 点击左侧 ==创建新项目->上传项目==
2. 将压缩包拖入页面
3. 等待上传完毕
4. 上传完毕后，在左上角点击菜单，在设置/编译器，选择 XeLaTeX
5. 按下 Ctrl-S 保存并自动编译

## Latex 相关

### 可视化编辑

[在线 LaTeX 公式编辑器 (codecogs.com)](https://latex.codecogs.com/legacy/eqneditor/editor.php?lang=zh-cn)

[AxMath/AxGlyph (amyxun.com)](https://www.amyxun.com/)

### 表格生成

[Create LaTeX tables online – TablesGenerator.com](https://www.tablesgenerator.com/)

- 在 Excel 处复制表格后，打开网页粘贴表格，点击 ==Generate== 自动生成代码

### 插入图片

常使用 [**!htbp**] 进行浮动排版（表格同理）：

```latex
\begin{figure}[!htbp]
	\centering
	\includegraphics[scale=0.5]{your-figure.png} 
	\caption{your caption}
	\label{fig:test1}
\end{figure}
```

### 文献引用

1. 在学术搜索引擎得到需要引用的文献的 bibtex 格式，粘贴到 reference/refs.bib 中
2. 使用 ==\cite{...}== 来进行 **角标引用** ，如“He 等人 \cite{hepaper} ”，渲染为“He 等人$^{\left[1\right]}$”
3. 使用 ==\citens{...}== 进行 **正文引用**，如“文献 \citens{hepaper}表明了...”，渲染为“文献 $\left[1\right]$ 表明了...”

> 当引用中文文献时，需要在该论文的 bibtex 中添加：
> ```latex
> language={zh-cn}
> ```
>
> 当引用中文学位论文时，需要在该论文的 bibtex 中添加：
>
> ```latex
> address = "作者学校的位置"
> ```

### 伪代码

1. 使用在 ==projpaper.tex== 的导言区（如第18行左右）添加 \usepackage[ruled,linesnumbered]{algorithm2e}

> 如需中文替换，请添加以下代码：
> ```latex
> \SetKwInput{KwIn}{输入}
> \SetKwInput{KwOut}{输出}
> \renewcommand{\algorithmcfname}{算法 -}
> ```

使用：
```latex
\begin{algorithm}
	
\renewcommand{\thealgocf}{1}
\SetAlgoLined
\caption{搜索算法}\label{algo-1}

步骤 1
步骤 2
	
\end{algorithm}
```

